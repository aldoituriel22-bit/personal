/**
 * @description Controller for the User Permission Matcher LWC component.
 * Provides methods to search users, compare permission sets, and assign missing ones.
 */
public with sharing class UserPermissionMatcherController {

    /**
     * @description Data transfer object representing a Salesforce user search result.
     */
    public class UserOption {
        @AuraEnabled public Id id;
        @AuraEnabled public String name;
        @AuraEnabled public String username;
        @AuraEnabled public String title;
        @AuraEnabled public String profileName;
    }

    /**
     * @description Data transfer object representing a permission set option.
     */
    public class PermissionOption {
        @AuraEnabled public Id id;
        @AuraEnabled public String label;
        @AuraEnabled public String name;
        @AuraEnabled public String description;
    }

    /**
     * @description Result object returned after assigning permission sets.
     */
    public class AssignmentResult {
        @AuraEnabled public Integer successCount = 0;
        @AuraEnabled public List<String> errors = new List<String>();
    }

    /**
     * @description Checks whether the current user is allowed to manage permissions for the target user.
     * System Administrators always have access. Other users must appear in the target user's
     * management chain (direct manager or any skip-level manager).
     * @param targetUserId The Id of the user whose permissions would be managed.
     * @return True if the current user is authorized, false otherwise.
     */
    @AuraEnabled(cacheable=true)
    public static Boolean canManageUser(Id targetUserId) {
        Id currentUserId = UserInfo.getUserId();

        User currentUser = [SELECT Profile.Name FROM User WHERE Id = :currentUserId WITH USER_MODE LIMIT 1];
        if (currentUser.Profile.Name == 'System Administrator') {
            return true;
        }

        Id checkUserId = targetUserId;
        Integer maxLevels = 10;
        Set<Id> visited = new Set<Id>();

        while (maxLevels-- > 0 && checkUserId != null) {
            List<User> managers = [SELECT ManagerId FROM User WHERE Id = :checkUserId WITH USER_MODE LIMIT 1];
            if (managers.isEmpty() || managers[0].ManagerId == null) {
                break;
            }
            Id managerId = managers[0].ManagerId;
            if (managerId == currentUserId) {
                return true;
            }
            if (visited.contains(managerId)) {
                break;
            }
            visited.add(managerId);
            checkUserId = managerId;
        }

        return false;
    }

    /**
     * @description Finds active users whose name contains the search term.
     * Excludes the user currently being viewed (the target).
     * @param searchTerm The search string to match against user names.
     * @param excludeUserId The Id of the user to exclude from results.
     * @return List of matching UserOption records.
     */
    @AuraEnabled
    public static List<UserOption> searchActiveUsers(String searchTerm, Id excludeUserId) {
        List<UserOption> options = new List<UserOption>();
        String term = searchTerm == null ? '' : searchTerm.trim();
        if (term.length() < 2) {
            return options;
        }
        String likeTerm = '%' + term + '%';

        for (User u : [
            SELECT Id, Name, Username, Title, Profile.Name
            FROM User
            WHERE IsActive = true
              AND Name LIKE :likeTerm
              AND Id != :excludeUserId
            WITH USER_MODE
            ORDER BY Name
            LIMIT 10
        ]) {
            UserOption o = new UserOption();
            o.id = u.Id;
            o.name = u.Name;
            o.username = u.Username;
            o.title = u.Title;
            o.profileName = u.Profile != null ? u.Profile.Name : null;
            options.add(o);
        }
        return options;
    }

    /**
     * @description Returns permission sets assigned to the source user that the target user does not have.
     * Profile-owned and permission-set-group component sets are skipped, because they cannot
     * be assigned individually.
     * @param sourceUserId The Id of the user to copy permissions from.
     * @param targetUserId The Id of the user to receive permissions.
     * @return List of PermissionOption records representing missing permission sets.
     */
    @AuraEnabled
    public static List<PermissionOption> getMissingPermissionSets(Id sourceUserId, Id targetUserId) {
        Set<Id> targetPermissionSetIds = new Set<Id>();
        for (PermissionSetAssignment psa : [
            SELECT PermissionSetId
            FROM PermissionSetAssignment
            WHERE AssigneeId = :targetUserId
            WITH USER_MODE
        ]) {
            targetPermissionSetIds.add(psa.PermissionSetId);
        }

        List<PermissionOption> missing = new List<PermissionOption>();
        for (PermissionSetAssignment psa : [
            SELECT PermissionSetId,
                   PermissionSet.Label,
                   PermissionSet.Name,
                   PermissionSet.Description
            FROM PermissionSetAssignment
            WHERE AssigneeId = :sourceUserId
              AND PermissionSet.IsOwnedByProfile = false
              AND PermissionSet.Type NOT IN ('Profile', 'Group')
            WITH USER_MODE
        ]) {
            if (targetPermissionSetIds.contains(psa.PermissionSetId)) {
                continue;
            }
            PermissionOption o = new PermissionOption();
            o.id          = psa.PermissionSetId;
            o.label       = psa.PermissionSet.Label;
            o.name        = psa.PermissionSet.Name;
            o.description = psa.PermissionSet.Description;
            missing.add(o);
        }
        return missing;
    }

    /**
     * @description Returns permission set groups assigned to the source user that the target user does not have.
     * @param sourceUserId The Id of the user to copy from.
     * @param targetUserId The Id of the user to receive the groups.
     * @return List of PermissionOption records representing missing permission set groups.
     */
    @AuraEnabled
    public static List<PermissionOption> getMissingPermissionSetGroups(Id sourceUserId, Id targetUserId) {
        Set<Id> targetIds = new Set<Id>();
        for (PermissionSetAssignment psa : [
            SELECT PermissionSetId
            FROM PermissionSetAssignment
            WHERE AssigneeId = :targetUserId
            WITH USER_MODE
        ]) {
            targetIds.add(psa.PermissionSetId);
        }

        List<PermissionOption> missing = new List<PermissionOption>();
        for (PermissionSetAssignment psa : [
            SELECT PermissionSetId,
                   PermissionSet.Label,
                   PermissionSet.Name,
                   PermissionSet.Description
            FROM PermissionSetAssignment
            WHERE AssigneeId = :sourceUserId
              AND PermissionSet.Type = 'Group'
            WITH USER_MODE
        ]) {
            if (targetIds.contains(psa.PermissionSetId)) {
                continue;
            }
            PermissionOption o = new PermissionOption();
            o.id          = psa.PermissionSetId;
            o.label       = psa.PermissionSet.Label;
            o.name        = psa.PermissionSet.Name;
            o.description = psa.PermissionSet.Description;
            missing.add(o);
        }
        return missing;
    }

    /**
     * @description Assigns the chosen permission sets to the target user.
     * The server re-checks that every id is in the source-vs-target difference,
     * so a client cannot assign arbitrary permission sets through this method.
     * @param sourceUserId The Id of the user to copy permissions from.
     * @param targetUserId The Id of the user to receive the permission sets.
     * @param permissionSetIds List of permission set Ids to assign.
     * @return AssignmentResult containing success count and any errors.
     */
    @AuraEnabled
    public static AssignmentResult assignPermissionSets(Id sourceUserId, Id targetUserId, List<Id> permissionSetIds) {
        AssignmentResult result = new AssignmentResult();
        if (!FeatureManagement.checkPermission('UserPermissionMatcher_CanAssign')) {
            result.errors.add('You do not have permission to assign permission sets.');
            return result;
        }
        if (permissionSetIds == null || permissionSetIds.isEmpty()) {
            return result;
        }

        // Build allowed set from both regular permission sets and permission set groups
        Set<Id> allowed = new Set<Id>();
        for (PermissionOption o : getMissingPermissionSets(sourceUserId, targetUserId)) {
            allowed.add(o.id);
        }
        for (PermissionOption o : getMissingPermissionSetGroups(sourceUserId, targetUserId)) {
            allowed.add(o.id);
        }

        // Fetch license requirements for each requested permission set
        Map<Id, String> psLicenseLabel = new Map<Id, String>();
        for (PermissionSet ps : [
            SELECT Id, Label, LicenseId
            FROM PermissionSet
            WHERE Id IN :permissionSetIds
              AND LicenseId != null
            WITH USER_MODE
        ]) {
            psLicenseLabel.put(ps.Id, ps.Label);
        }

        // Fetch the target user's license so we can block incompatible assignments up front
        User targetUser = [
            SELECT Profile.UserLicenseId
            FROM User
            WHERE Id = :targetUserId
            WITH USER_MODE
            LIMIT 1
        ];
        Id userLicenseId = (targetUser.Profile != null) ? targetUser.Profile.UserLicenseId : null;

        Map<Id, Id> psRequiredLicense = new Map<Id, Id>();
        for (PermissionSet ps : [
            SELECT Id, LicenseId
            FROM PermissionSet
            WHERE Id IN :permissionSetIds
              AND LicenseId != null
            WITH USER_MODE
        ]) {
            psRequiredLicense.put(ps.Id, ps.LicenseId);
        }

        Set<Id> seen = new Set<Id>();
        List<PermissionSetAssignment> toInsert = new List<PermissionSetAssignment>();
        for (Id psId : permissionSetIds) {
            if (!allowed.contains(psId) || !seen.add(psId)) {
                continue;
            }
            Id requiredLicense = psRequiredLicense.get(psId);
            if (requiredLicense != null && requiredLicense != userLicenseId) {
                String label = psLicenseLabel.containsKey(psId) ? psLicenseLabel.get(psId) : String.valueOf(psId);
                result.errors.add(label + ': requires a license this user does not have.');
                continue;
            }
            toInsert.add(new PermissionSetAssignment(AssigneeId = targetUserId, PermissionSetId = psId));
        }
        if (toInsert.isEmpty()) {
            return result;
        }

        // allOrNone = false so one failing assignment does not block the rest
        Database.SaveResult[] saveResults = Database.insert(toInsert, false, AccessLevel.USER_MODE);
        for (Database.SaveResult sr : saveResults) {
            if (sr.isSuccess()) {
                result.successCount++;
            } else {
                for (Database.Error err : sr.getErrors()) {
                    result.errors.add(err.getMessage());
                }
            }
        }
        return result;
    }

    // ---- Compare Users tab ----

    /**
     * @description Data transfer object representing a single feature licence flag on a user.
     */
    public class FeatureLicenseItem {
        @AuraEnabled public String  label;
        @AuraEnabled public Boolean enabled;
    }

    /**
     * @description Snapshot of a user's identity, licence and group/queue membership
     *              for display in the Compare Users tab.
     */
    public class UserCompareData {
        @AuraEnabled public Id     userId;
        @AuraEnabled public String name;
        @AuraEnabled public String profileName;
        @AuraEnabled public String roleName;
        @AuraEnabled public String managerName;
        @AuraEnabled public String division;
        @AuraEnabled public String department;
        @AuraEnabled public String userLicense;
        @AuraEnabled public List<FeatureLicenseItem> featureLicenses;
        @AuraEnabled public List<String> publicGroups;
        @AuraEnabled public List<String> queues;
    }

    /**
     * @description Returns a structured snapshot of the requested user's identity, licence
     *              and group/queue membership for the Compare Users tab.
     * @param userId The Id of the user to fetch data for.
     * @return Populated UserCompareData instance.
     */
    @AuraEnabled
    public static UserCompareData getUserCompareData(Id userId) {
        User u = [
            SELECT Id, Name, Profile.Name, UserRole.Name, Manager.Name,
                   Division, Department, UserType,
                   UserPermissionsMarketingUser,
                   UserPermissionsOfflineUser,
                   UserPermissionsSFContentUser,
                   UserPermissionsCallCenterAutoLogin,
                   UserPermissionsInteractionUser,
                   UserPermissionsKnowledgeUser,
                   UserPermissionsLiveAgentUser
            FROM User
            WHERE Id = :userId
            WITH USER_MODE
            LIMIT 1
        ];

        UserCompareData data  = new UserCompareData();
        data.userId           = u.Id;
        data.name             = u.Name;
        data.profileName      = u.Profile  != null ? u.Profile.Name  : null;
        data.roleName         = u.UserRole != null ? u.UserRole.Name  : null;
        data.managerName      = u.Manager  != null ? u.Manager.Name   : null;
        data.division         = u.Division;
        data.department       = u.Department;
        data.userLicense      = u.UserType;

        data.featureLicenses = new List<FeatureLicenseItem>{
            makeFLI('Marketing User',           u.UserPermissionsMarketingUser),
            makeFLI('Offline User',             u.UserPermissionsOfflineUser),
            makeFLI('CRM Content User',         u.UserPermissionsSFContentUser),
            makeFLI('Call Center Auto-Login',   u.UserPermissionsCallCenterAutoLogin),
            makeFLI('Flow User',                u.UserPermissionsInteractionUser),
            makeFLI('Knowledge User',           u.UserPermissionsKnowledgeUser),
            makeFLI('Live Agent (Chat) User',   u.UserPermissionsLiveAgentUser)
        };

        data.publicGroups = new List<String>();
        data.queues       = new List<String>();
        for (GroupMember gm : [
            SELECT Group.Name, Group.Type
            FROM GroupMember
            WHERE UserOrGroupId = :userId
              AND Group.Type IN ('Regular', 'Queue')
            WITH USER_MODE
            ORDER BY Group.Name
        ]) {
            if (gm.Group.Type == 'Regular') {
                data.publicGroups.add(gm.Group.Name);
            } else {
                data.queues.add(gm.Group.Name);
            }
        }

        return data;
    }

    private static FeatureLicenseItem makeFLI(String label, Boolean enabled) {
        FeatureLicenseItem item = new FeatureLicenseItem();
        item.label   = label;
        item.enabled = enabled == true;
        return item;
    }
}