@IsTest
private class UserPermissionMatcherControllerTest {

    @TestSetup
    static void setup() {
        Profile p = [SELECT Id FROM Profile WHERE Name = 'Standard User' LIMIT 1];
        String suffix = String.valueOf(DateTime.now().getTime());

        User source = new User(
            FirstName = 'Src', LastName = 'UPMSourceQ7', Alias = 'upmsrc',
            Email = 'upm.source@example.com',
            Username = 'upm.source.' + suffix + '@example.com',
            ProfileId = p.Id, TimeZoneSidKey = 'America/New_York',
            LocaleSidKey = 'en_US', EmailEncodingKey = 'UTF-8', LanguageLocaleKey = 'en_US'
        );
        User target = new User(
            FirstName = 'Tgt', LastName = 'Target', Alias = 'upmtgt',
            Email = 'upm.target@example.com',
            Username = 'upm.target.' + suffix + '@example.com',
            ProfileId = p.Id, TimeZoneSidKey = 'America/New_York',
            LocaleSidKey = 'en_US', EmailEncodingKey = 'UTF-8', LanguageLocaleKey = 'en_US'
        );
        insert new List<User>{ source, target };
    }

    @IsTest
    static void missingPermissionSetsReturnsOnlyTheDifference() {
        User source = [SELECT Id FROM User WHERE Username LIKE 'upm.source.%' LIMIT 1];
        User target = [SELECT Id FROM User WHERE Username LIKE 'upm.target.%' LIMIT 1];

        PermissionSet psA = new PermissionSet(Name = 'UPM_Test_A', Label = 'UPM Test A');
        PermissionSet psB = new PermissionSet(Name = 'UPM_Test_B', Label = 'UPM Test B');
        insert new List<PermissionSet>{ psA, psB };

        insert new List<PermissionSetAssignment>{
            new PermissionSetAssignment(AssigneeId = source.Id, PermissionSetId = psA.Id),
            new PermissionSetAssignment(AssigneeId = source.Id, PermissionSetId = psB.Id),
            new PermissionSetAssignment(AssigneeId = target.Id, PermissionSetId = psA.Id)
        };

        Test.startTest();
        List<UserPermissionMatcherController.PermissionOption> missing =
            UserPermissionMatcherController.getMissingPermissionSets(source.Id, target.Id);
        Test.stopTest();

        System.assertEquals(1, missing.size(), 'Only permission set B should be missing');
        System.assertEquals(psB.Id, missing[0].id);
    }

    @IsTest
    static void assignAddsOnlyAllowedPermissionSets() {
        User source = [SELECT Id FROM User WHERE Username LIKE 'upm.source.%' LIMIT 1];
        User target = [SELECT Id FROM User WHERE Username LIKE 'upm.target.%' LIMIT 1];

        PermissionSet psB = new PermissionSet(Name = 'UPM_Test_B2', Label = 'UPM Test B2');
        PermissionSet psUnrelated = new PermissionSet(Name = 'UPM_Test_Unrelated', Label = 'UPM Unrelated');
        insert new List<PermissionSet>{ psB, psUnrelated };
        insert new PermissionSetAssignment(AssigneeId = source.Id, PermissionSetId = psB.Id);

        Test.startTest();
        UserPermissionMatcherController.AssignmentResult result =
            UserPermissionMatcherController.assignPermissionSets(
                source.Id, target.Id, new List<Id>{ psB.Id, psUnrelated.Id }
            );
        Test.stopTest();

        // psUnrelated is not held by the source user, so the server must skip it
        System.assertEquals(1, result.successCount);
        System.assertEquals(0, result.errors.size());

        Integer assigned = [
            SELECT COUNT() FROM PermissionSetAssignment
            WHERE AssigneeId = :target.Id AND PermissionSetId = :psB.Id
        ];
        System.assertEquals(1, assigned);
        Integer unrelatedAssigned = [
            SELECT COUNT() FROM PermissionSetAssignment
            WHERE AssigneeId = :target.Id AND PermissionSetId = :psUnrelated.Id
        ];
        System.assertEquals(0, unrelatedAssigned);
    }

    @IsTest
    static void searchReturnsMatchingActiveUsersAndExcludesTarget() {
        User target = [SELECT Id FROM User WHERE Username LIKE 'upm.target.%' LIMIT 1];

        Test.startTest();
        List<UserPermissionMatcherController.UserOption> found =
            UserPermissionMatcherController.searchActiveUsers('UPMSourceQ7', target.Id);
        List<UserPermissionMatcherController.UserOption> tooShort =
            UserPermissionMatcherController.searchActiveUsers('S', target.Id);
        Test.stopTest();

        System.assertEquals(1, found.size());
        System.assertEquals('Src UPMSourceQ7', found[0].name);
        System.assertEquals(0, tooShort.size());
    }

    @IsTest
    static void getUserCompareDataReturnsIdentityAndLicenceFields() {
        User source = [SELECT Id FROM User WHERE Username LIKE 'upm.source.%' LIMIT 1];

        Test.startTest();
        UserPermissionMatcherController.UserCompareData data =
            UserPermissionMatcherController.getUserCompareData(source.Id);
        Test.stopTest();

        System.assertNotEquals(null, data,                   'Data should not be null');
        System.assertEquals(source.Id, data.userId,         'userId must match');
        System.assertEquals('Src UPMSourceQ7', data.name,   'Name must match');
        System.assertNotEquals(null, data.featureLicenses,  'Feature licences list should not be null');
        System.assert(data.featureLicenses.size() > 0,      'Feature licences should be populated');
        System.assertNotEquals(null, data.publicGroups,     'Public groups list should not be null');
        System.assertNotEquals(null, data.queues,           'Queues list should not be null');
    }

    @IsTest
    static void getUserCompareDataIncludesGroupMembership() {
        User source = [SELECT Id FROM User WHERE Username LIKE 'upm.source.%' LIMIT 1];

        Group grp = new Group(Name = 'UPM_Test_Group', Type = 'Regular');
        insert grp;
        insert new GroupMember(GroupId = grp.Id, UserOrGroupId = source.Id);

        Test.startTest();
        UserPermissionMatcherController.UserCompareData data =
            UserPermissionMatcherController.getUserCompareData(source.Id);
        Test.stopTest();

        System.assertEquals(1, data.publicGroups.size(), 'Should include the test group');
        System.assertEquals('UPM_Test_Group', data.publicGroups[0]);
        System.assertEquals(0, data.queues.size(),        'No queue membership expected');
    }
}