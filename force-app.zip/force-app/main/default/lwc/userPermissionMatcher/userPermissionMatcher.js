import { LightningElement, api } from 'lwc';
import canAssignPermissions from '@salesforce/customPermission/UserPermissionMatcher_CanAssign';
import searchActiveUsers from '@salesforce/apex/UserPermissionMatcherController.searchActiveUsers';
import getMissingPermissionSets from '@salesforce/apex/UserPermissionMatcherController.getMissingPermissionSets';
import assignPermissionSets from '@salesforce/apex/UserPermissionMatcherController.assignPermissionSets';
import canManageUser from '@salesforce/apex/UserPermissionMatcherController.canManageUser';
import getMissingPermissionSetGroups from '@salesforce/apex/UserPermissionMatcherController.getMissingPermissionSetGroups';
import getUserCompareData from '@salesforce/apex/UserPermissionMatcherController.getUserCompareData';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

const COLUMNS = [
    { label: 'Permission Set', fieldName: 'label',       type: 'text' },
    { label: 'API Name',       fieldName: 'name',        type: 'text' },
    { label: 'Description',    fieldName: 'description', type: 'text', wrapText: true }
];

const SEARCH_DEBOUNCE_MS = 300;
const ROW_BASE  = 'compare-row';
const ROW_DIFF  = 'compare-row compare-row_diff';
const CHECK     = '✓';
const DASH      = '—';

export default class UserPermissionMatcher extends LightningElement {
    @api recordId;

    // ---- Match Permissions tab ----
    columns              = COLUMNS;
    searchTerm           = '';
    searchResults        = [];
    isSearching          = false;
    sourceUser           = null;
    missingPermissions   = [];
    selectedRowIds       = [];
    isLoadingPermissions = false;
    isAssigning          = false;
    isAuthorized         = false;
    isCheckingAccess     = true;
    searchTimer;
    // PSG section
    missingPSGs          = [];
    selectedPSGRowIds    = [];
    isLoadingPSGs        = false;
    isAssigningPSGs      = false;
    psgSectionOpen       = false;

    // ---- Compare Users tab ----
    cmpSearchTerm          = '';
    cmpSearchResults       = [];
    cmpIsSearching         = false;
    cmpUser                = null;
    cmpData1               = null;
    cmpData2               = null;
    cmpLoading             = false;
    showDiffOnly           = false;
    cmpIdentityOpen        = false;
    cmpAccessOpen          = false;
    cmpPublicGroupsOpen    = false;
    cmpQueuesOpen          = false;
    cmpLicenseOpen         = false;
    cmpFeatureLicensesOpen = false;
    cmpSearchTimer;

    async connectedCallback() {
        try {
            this.isAuthorized = await canManageUser({ targetUserId: this.recordId });
        } catch (error) {
            this.isAuthorized = false;
        } finally {
            this.isCheckingAccess = false;
        }
    }

    // ================================================================
    // Match Permissions tab — derived state
    // ================================================================
    get canAssign()           { return canAssignPermissions === true; }
    get isReadOnly()          { return !canAssignPermissions; }
    get hasSourceUser()       { return this.sourceUser !== null; }
    get hasSearchResults()    { return this.searchResults.length > 0; }
    get hasMissing()          { return this.missingPermissions.length > 0; }
    get showNoMissingMessage(){ return this.hasSourceUser && !this.isLoadingPermissions && !this.hasMissing; }
    get assignSelectedLabel() { return `Add Selected (${this.selectedRowIds.length})`; }
    get assignAllLabel()      { return `Add All (${this.missingPermissions.length})`; }
    get disableAssignSelected(){ return this.isAssigning || this.selectedRowIds.length === 0; }
    get disableAssignAll()    { return this.isAssigning || !this.hasMissing; }

    // PSG section
    get hasMissingPSGs()          { return this.missingPSGs.length > 0; }
    get showNoPSGMessage()        { return this.sourceUser !== null && !this.isLoadingPSGs && !this.hasMissingPSGs; }
    get psgSectionIcon()          { return this.psgSectionOpen ? 'utility:chevrondown' : 'utility:chevronright'; }
    get psgSectionLabel()         { return this.hasMissingPSGs ? `Permission Set Groups (${this.missingPSGs.length})` : 'Permission Set Groups'; }
    get assignSelectedPSGLabel()  { return `Add Selected (${this.selectedPSGRowIds.length})`; }
    get assignAllPSGLabel()       { return `Add All (${this.missingPSGs.length})`; }
    get disableAssignSelectedPSG(){ return this.isAssigningPSGs || this.selectedPSGRowIds.length === 0; }
    get disableAssignAllPSG()     { return this.isAssigningPSGs || !this.hasMissingPSGs; }

    // ================================================================
    // Match Permissions tab — handlers
    // ================================================================
    handleSearchChange(event) {
        this.searchTerm = event.target.value;
        clearTimeout(this.searchTimer);
        this.searchTimer = setTimeout(() => this.runSearch(), SEARCH_DEBOUNCE_MS);
    }

    async runSearch() {
        if (this.searchTerm.trim().length < 2) {
            this.searchResults = [];
            return;
        }
        this.isSearching = true;
        try {
            this.searchResults = await searchActiveUsers({ searchTerm: this.searchTerm, excludeUserId: this.recordId });
        } catch (error) {
            this.showToast('Search failed', this.errorMessage(error), 'error');
        } finally {
            this.isSearching = false;
        }
    }

    async handleSelectUser(event) {
        const userId = event.currentTarget.dataset.id;
        const picked = this.searchResults.find((u) => u.id === userId);
        if (!picked) return;
        this.sourceUser    = picked;
        this.searchResults = [];
        this.searchTerm    = '';
        await Promise.all([this.loadMissingPermissions(), this.loadMissingPSGs()]);
    }

    clearSourceUser() {
        this.sourceUser         = null;
        this.missingPermissions = [];
        this.selectedRowIds     = [];
        this.missingPSGs        = [];
        this.selectedPSGRowIds  = [];
    }

    async loadMissingPermissions() {
        this.isLoadingPermissions = true;
        this.selectedRowIds       = [];
        try {
            this.missingPermissions = await getMissingPermissionSets({
                sourceUserId: this.sourceUser.id,
                targetUserId: this.recordId
            });
        } catch (error) {
            this.missingPermissions = [];
            this.showToast('Could not load permissions', this.errorMessage(error), 'error');
        } finally {
            this.isLoadingPermissions = false;
        }
    }

    async loadMissingPSGs() {
        this.isLoadingPSGs    = true;
        this.selectedPSGRowIds = [];
        try {
            this.missingPSGs = await getMissingPermissionSetGroups({
                sourceUserId: this.sourceUser.id,
                targetUserId: this.recordId
            });
        } catch (error) {
            this.missingPSGs = [];
            this.showToast('Could not load permission set groups', this.errorMessage(error), 'error');
        } finally {
            this.isLoadingPSGs = false;
        }
    }

    handleRowSelection(event) {
        this.selectedRowIds = event.detail.selectedRows.map((row) => row.id);
    }

    handleAddSelected() { return this.assign(this.selectedRowIds); }
    handleAddAll()      { return this.assign(this.missingPermissions.map((p) => p.id)); }
    handlePSGRowSelection(event) { this.selectedPSGRowIds = event.detail.selectedRows.map((r) => r.id); }
    handleAddSelectedPSG()       { return this.assignPSGs(this.selectedPSGRowIds); }
    handleAddAllPSG()            { return this.assignPSGs(this.missingPSGs.map((p) => p.id)); }
    togglePSGSection()           { this.psgSectionOpen = !this.psgSectionOpen; }

    async assign(permissionSetIds) {
        if (permissionSetIds.length === 0) return;
        this.isAssigning = true;
        try {
            const result = await assignPermissionSets({
                sourceUserId:    this.sourceUser.id,
                targetUserId:    this.recordId,
                permissionSetIds
            });
            if (result.successCount > 0) {
                this.showToast('Permissions added', `${result.successCount} permission set(s) assigned.`, 'success');
            }
            if (result.errors.length > 0) {
                this.showToast('Some assignments failed', result.errors.join(' | '), 'warning');
            }
            await Promise.all([this.loadMissingPermissions(), this.loadMissingPSGs()]);
        } catch (error) {
            this.showToast('Assignment failed', this.errorMessage(error), 'error');
        } finally {
            this.isAssigning = false;
        }
    }

    async assignPSGs(permissionSetIds) {
        if (permissionSetIds.length === 0) return;
        this.isAssigningPSGs = true;
        try {
            const result = await assignPermissionSets({
                sourceUserId:    this.sourceUser.id,
                targetUserId:    this.recordId,
                permissionSetIds
            });
            if (result.successCount > 0) {
                this.showToast('Groups added', `${result.successCount} permission set group(s) assigned.`, 'success');
            }
            if (result.errors.length > 0) {
                this.showToast('Some assignments failed', result.errors.join(' | '), 'warning');
            }
            await this.loadMissingPSGs();
        } catch (error) {
            this.showToast('Assignment failed', this.errorMessage(error), 'error');
        } finally {
            this.isAssigningPSGs = false;
        }
    }

    // ================================================================
    // Compare Users tab — derived state
    // ================================================================
    get hasCmpUser()        { return this.cmpUser !== null; }
    get cmpHasSearchResults(){ return this.cmpSearchResults.length > 0; }
    get cmpUser1Name()      { return this.cmpData1 ? this.cmpData1.name : '—'; }
    get cmpUser2Name()      { return this.cmpData2 ? this.cmpData2.name : '—'; }

    // Section expand icons
    get cmpIdentityIcon()        { return this.cmpIdentityOpen        ? 'utility:chevrondown' : 'utility:chevronright'; }
    get cmpAccessIcon()          { return this.cmpAccessOpen          ? 'utility:chevrondown' : 'utility:chevronright'; }
    get cmpPublicGroupsIcon()    { return this.cmpPublicGroupsOpen    ? 'utility:chevrondown' : 'utility:chevronright'; }
    get cmpQueuesIcon()          { return this.cmpQueuesOpen          ? 'utility:chevrondown' : 'utility:chevronright'; }
    get cmpLicenseIcon()         { return this.cmpLicenseOpen         ? 'utility:chevrondown' : 'utility:chevronright'; }
    get cmpFeatureLicensesIcon() { return this.cmpFeatureLicensesOpen ? 'utility:chevrondown' : 'utility:chevronright'; }

    // Identity rows
    get cmpIdentityRows() {
        if (!this.cmpData1 || !this.cmpData2) return [];
        const rows = [
            this.makeRow('profile',    'Profile',    this.cmpData1.profileName,  this.cmpData2.profileName),
            this.makeRow('role',       'Role',       this.cmpData1.roleName,     this.cmpData2.roleName),
            this.makeRow('manager',    'Manager',    this.cmpData1.managerName,  this.cmpData2.managerName),
            this.makeRow('division',   'Division',   this.cmpData1.division,     this.cmpData2.division),
            this.makeRow('department', 'Department', this.cmpData1.department,   this.cmpData2.department)
        ];
        return this.showDiffOnly ? rows.filter((r) => r.isDiff) : rows;
    }
    get cmpIdentityHasRows() { return this.cmpIdentityRows.length > 0; }

    // Public Groups rows — union of both users' groups
    get cmpPublicGroupRows() {
        if (!this.cmpData1 || !this.cmpData2) return [];
        return this.buildMembershipRows(this.cmpData1.publicGroups, this.cmpData2.publicGroups);
    }
    get cmpPublicGroupHasRows() { return this.cmpPublicGroupRows.length > 0; }

    // Queue rows
    get cmpQueueRows() {
        if (!this.cmpData1 || !this.cmpData2) return [];
        return this.buildMembershipRows(this.cmpData1.queues, this.cmpData2.queues);
    }
    get cmpQueueHasRows() { return this.cmpQueueRows.length > 0; }

    // User License row
    get cmpUserLicenseRow() {
        const v1 = (this.cmpData1 && this.cmpData1.userLicense) ? this.cmpData1.userLicense : DASH;
        const v2 = (this.cmpData2 && this.cmpData2.userLicense) ? this.cmpData2.userLicense : DASH;
        const isDiff = v1 !== v2;
        return { v1, v2, isDiff, rowCss: isDiff ? ROW_DIFF : ROW_BASE };
    }
    get cmpShowUserLicenseRow() {
        if (!this.cmpData1 || !this.cmpData2) return false;
        return !this.showDiffOnly || this.cmpUserLicenseRow.isDiff;
    }

    // Feature License rows
    get cmpFeatureLicenseRows() {
        if (!this.cmpData1 || !this.cmpData2) return [];
        const map2 = {};
        (this.cmpData2.featureLicenses || []).forEach((fl) => { map2[fl.label] = fl.enabled; });
        const rows = (this.cmpData1.featureLicenses || []).map((fl) => {
            const e1    = fl.enabled === true;
            const e2    = map2[fl.label] === true;
            const isDiff = e1 !== e2;
            return { key: fl.label, label: fl.label, v1: e1 ? CHECK : DASH, v2: e2 ? CHECK : DASH, isDiff, rowCss: isDiff ? ROW_DIFF : ROW_BASE };
        });
        return this.showDiffOnly ? rows.filter((r) => r.isDiff) : rows;
    }
    get cmpFeatureLicenseHasRows() { return this.cmpFeatureLicenseRows.length > 0; }

    // ================================================================
    // Compare Users tab — handlers
    // ================================================================
    handleCmpSearchChange(event) {
        this.cmpSearchTerm = event.target.value;
        clearTimeout(this.cmpSearchTimer);
        this.cmpSearchTimer = setTimeout(() => this.runCmpSearch(), SEARCH_DEBOUNCE_MS);
    }

    async runCmpSearch() {
        if (this.cmpSearchTerm.trim().length < 2) {
            this.cmpSearchResults = [];
            return;
        }
        this.cmpIsSearching = true;
        try {
            this.cmpSearchResults = await searchActiveUsers({ searchTerm: this.cmpSearchTerm, excludeUserId: this.recordId });
        } catch (error) {
            this.showToast('Search failed', this.errorMessage(error), 'error');
        } finally {
            this.cmpIsSearching = false;
        }
    }

    async handleCmpSelectUser(event) {
        const userId = event.currentTarget.dataset.id;
        const picked = this.cmpSearchResults.find((u) => u.id === userId);
        if (!picked) return;
        this.cmpUser          = picked;
        this.cmpSearchResults = [];
        this.cmpSearchTerm    = '';
        await this.loadCompareData(userId);
    }

    async loadCompareData(user2Id) {
        this.cmpLoading = true;
        this.cmpData1   = null;
        this.cmpData2   = null;
        try {
            [this.cmpData1, this.cmpData2] = await Promise.all([
                getUserCompareData({ userId: this.recordId }),
                getUserCompareData({ userId: user2Id })
            ]);
        } catch (error) {
            this.showToast('Could not load comparison data', this.errorMessage(error), 'error');
        } finally {
            this.cmpLoading = false;
        }
    }

    clearCmpUser() {
        this.cmpUser    = null;
        this.cmpData1   = null;
        this.cmpData2   = null;
        this.showDiffOnly           = false;
        this.cmpIdentityOpen        = false;
        this.cmpAccessOpen          = false;
        this.cmpPublicGroupsOpen    = false;
        this.cmpQueuesOpen          = false;
        this.cmpLicenseOpen         = false;
        this.cmpFeatureLicensesOpen = false;
    }

    handleDiffToggle(event)       { this.showDiffOnly           = event.target.checked; }
    toggleCmpIdentity()           { this.cmpIdentityOpen        = !this.cmpIdentityOpen; }
    toggleCmpAccess()             { this.cmpAccessOpen          = !this.cmpAccessOpen; }
    toggleCmpPublicGroups()       { this.cmpPublicGroupsOpen    = !this.cmpPublicGroupsOpen; }
    toggleCmpQueues()             { this.cmpQueuesOpen          = !this.cmpQueuesOpen; }
    toggleCmpLicense()            { this.cmpLicenseOpen         = !this.cmpLicenseOpen; }
    toggleCmpFeatureLicenses()    { this.cmpFeatureLicensesOpen = !this.cmpFeatureLicensesOpen; }

    // ================================================================
    // Helpers
    // ================================================================
    makeRow(key, label, raw1, raw2) {
        const v1     = raw1 || DASH;
        const v2     = raw2 || DASH;
        const isDiff = v1 !== v2;
        return { key, label, v1, v2, isDiff, rowCss: isDiff ? ROW_DIFF : ROW_BASE };
    }

    buildMembershipRows(list1, list2) {
        const set1  = new Set(list1 || []);
        const set2  = new Set(list2 || []);
        const all   = [...new Set([...set1, ...set2])].sort();
        const rows  = all.map((name) => {
            const has1   = set1.has(name);
            const has2   = set2.has(name);
            const isDiff = has1 !== has2;
            return { key: name, label: name, v1: has1 ? CHECK : DASH, v2: has2 ? CHECK : DASH, isDiff, rowCss: isDiff ? ROW_DIFF : ROW_BASE };
        });
        return this.showDiffOnly ? rows.filter((r) => r.isDiff) : rows;
    }

    errorMessage(error) {
        return (error && error.body && error.body.message) || 'Unexpected error.';
    }

    showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}
